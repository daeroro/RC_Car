
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_hal.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include "math.h"
#include "MPU9250.h"
#include <stdlib.h>
#include <string.h>
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void MPU9250_init(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
int _write(int file, char *p, int len)
{
	HAL_UART_Transmit(&huart2, p, len, 10);
	return len;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint8_t whoami;
	uint8_t str[50] = {0};
	uint8_t str1[100] = {0};
	uint8_t str2[100] = {0};
	uint8_t str3[100] = {0};
	uint8_t str4[100] = {0};
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  whoami = readByte(MPU9250_ADDRESS, WHO_AM_I_MPU9250);
  sprintf(str, "str = 0x%x\r\n", whoami);
  HAL_UART_Transmit(&huart2, str, 30, 10);

  if(whoami == 0x71)
  {
	  resetMPU9250();

	  calibrateMPU9250(gyroBias, accelBias); // Calibrate gyro and accelerometers, load biases in bias registers

	  sprintf(str, "x gyro bias = %f\n\r", gyroBias[0]);
	  HAL_UART_Transmit(&huart2, str, 50, 10);
	  sprintf(str, "y gyro bias = %f\n\r", gyroBias[1]);
	  HAL_UART_Transmit(&huart2, str, 50, 10);
	  sprintf(str, "z gyro bias = %f\n\r", gyroBias[2]);
	  HAL_UART_Transmit(&huart2, str, 50, 10);

	  HAL_UART_Transmit(&huart2, "\r\n", 2, 10);
	  sprintf(str, "x accel bias = %f\n\r", accelBias[0]);
	  HAL_UART_Transmit(&huart2, str, 50, 10);
	  sprintf(str, "y accel bias = %f\n\r", accelBias[1]);
	  HAL_UART_Transmit(&huart2, str, 50, 10);
	  sprintf(str, "z accel bias = %f\n\r", accelBias[2]);
	  HAL_UART_Transmit(&huart2, str, 50, 10);

	  HAL_UART_Transmit(&huart2, "\r\n\n", 5, 10);

	  initMPU9250();

	  initAK8963(magCalibration);

	  if(Mscale == 0)
	  {
		  sprintf(str, "Magnetometer resolution = 14  bits\n\r");
		  HAL_UART_Transmit(&huart2, str, 50, 10);
	  }
	  if(Mscale == 1)
	  {
		  sprintf(str, "Magnetometer resolution = 16  bits\n\r");
		  HAL_UART_Transmit(&huart2, str, 50, 10);
	  }
	  if(Mmode == 2)
	  {
		  sprintf(str, "Magnetometer ODR = 8 Hz\n\r");
		  HAL_UART_Transmit(&huart2, str, 50, 10);
	  }
	  if(Mmode == 6)
	  {
		  sprintf(str, "Magnetometer ODR = 100 Hz\n\r");
		  HAL_UART_Transmit(&huart2, str, 50, 10);
	  }

	  HAL_Delay(200);
  }
  else
  {
	  sprintf(str, "Could not connect to MPU9250: \r\n");
	  HAL_UART_Transmit(&huart2, str, 50, 10);
	  while(1);
  }


  getAres();	// get accelerometer sensitivity
  getGres();	// get gyro sensitivity
  getMres();	// get magnetometer sensitivity

  sprintf(str, "Accelerometer sensitivity is %f LSB/g \r\n", 1.0f/aRes);
  HAL_UART_Transmit(&huart2, str, 50, 10);

  sprintf(str, "Gyroscope sensitivity is %f LSB/deg/s \n\r", 1.0f/gRes);
  HAL_UART_Transmit(&huart2, str, 50, 10);

  sprintf(str, "Magnetometer sensitivity is %f LSB/G \n\r", 1.0f/mRes);
  HAL_UART_Transmit(&huart2, str, 50, 10);

  magbias[0] = +470.;  // User environmental x-axis correction in milliGauss, should be automatically calculated
  magbias[1] = +120.;  // User environmental x-axis correction in milliGauss
  magbias[2] = +125.;  // User environmental x-axis correction in milliGauss

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1)
	{
  /* USER CODE END WHILE */
  /* USER CODE BEGIN 3 */
		 if(readByte(MPU9250_ADDRESS, INT_STATUS) & 0x01) // On interrupt, check if data ready interrupt
		 {
			readAccelData(accelCount);  // Read the x/y/z adc values
			// Now we'll calculate the accleration value into actual g's
			ax = (float)accelCount[0]*aRes - accelBias[0];  // get actual g value, this depends on scale being set
			ay = (float)accelCount[1]*aRes - accelBias[1];
			az = (float)accelCount[2]*aRes - accelBias[2];

			readGyroData(gyroCount);  // Read the x/y/z adc values
			// Calculate the gyro value into actual degrees per second
			gx = (float)gyroCount[0]*gRes - gyroBias[0];  // get actual gyro value, this depends on scale being set
			gy = (float)gyroCount[1]*gRes - gyroBias[1];
			gz = (float)gyroCount[2]*gRes - gyroBias[2];

			readMagData(magCount);  // Read the x/y/z adc values
			// Calculate the magnetometer values in milliGauss
			// Include factory calibration per data sheet and user environmental corrections
			mx = (float)magCount[0]*mRes*magCalibration[0] - magbias[0];  // get actual magnetometer value, this depends on scale being set
			my = (float)magCount[1]*mRes*magCalibration[1] - magbias[1];
			mz = (float)magCount[2]*mRes*magCalibration[2] - magbias[2];
		  }

		 MadgwickQuaternionUpdate(ax, ay, az, gx*PI/180.0f, gy*PI/180.0f, gz*PI/180.0f,  my,  mx, mz);

		 //delt_t = t.read_ms() - count;

		tempCount = readTempData();  // Read the adc values
		temperature = ((float) tempCount) / 333.87f + 21.0f; // Temperature in degrees Centigrade

		 sprintf(str1, "ax = %f	  ay = %f   az = %f  mg", 1000*ax, 1000*ay, 1000*az);
		 HAL_UART_Transmit(&huart2, str1, sizeof(str1), 10);
		 HAL_UART_Transmit(&huart2, "\r\n", 2, 10);

		 sprintf(str2, "gx = %f	  gy = %f   gz = %f  deg/s", gx, gy, gz);
		 HAL_UART_Transmit(&huart2, str2, sizeof(str2), 10);
		 HAL_UART_Transmit(&huart2, "\r\n", 2, 10);

		 sprintf(str3, "mx = %f  my = %f  mz = %f mG", mx, my, mz);
		 HAL_UART_Transmit(&huart2, str3, sizeof(str3), 10);
		 HAL_UART_Transmit(&huart2, "\r\n", 2, 10);

		sprintf(str4, "temperature = %f  C\r\n\n", temperature);
		HAL_UART_Transmit(&huart2, str4, sizeof(str4), 10);

		HAL_Delay(1000);
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Configure the main internal regulator output voltage 
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
